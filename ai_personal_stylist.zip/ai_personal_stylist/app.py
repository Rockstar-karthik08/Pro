from flask import Flask, render_template, request
import pickle
import os

app = Flask(__name__)

# Load model and encoders
with open('model/stylist_model.pkl', 'rb') as f:
    model, encoder_season, encoder_occasion, encoder_body_type, encoder_clothing_type = pickle.load(f)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/", methods=["POST"])
def predict():
    if request.method == "POST":
        season = request.form["season"]
        occasion = request.form["occasion"]
        body_type = request.form["body_type"]

        # Encode input
        input_data = [
            encoder_season.transform([season])[0],
            encoder_occasion.transform([occasion])[0],
            encoder_body_type.transform([body_type])[0],
        ]

        # Predict clothing type
        prediction_index = model.predict([input_data])[0]
        prediction = encoder_clothing_type.inverse_transform([prediction_index])[0]

        # Map prediction to image path
        image_path = f"static/images/{prediction.lower()}.jpg"

        return render_template(
            "index.html",
            prediction=prediction,
            image_path=image_path
        )

if __name__ == "__main__":
    app.run(debug=True)
