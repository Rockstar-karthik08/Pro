import spacy
from flask import Flask, render_template, request
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
import nltk
from werkzeug.utils import secure_filename
import os
from PyPDF2 import PdfReader

# Download NLTK stopwords
nltk.download('stopwords')

# Initialize Flask app
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = './uploads'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Load the spaCy English model
nlp = spacy.load("en_core_web_sm")

# Precompute stopwords and initialize stemmer
stop_words = set(stopwords.words('english'))
stemmer = PorterStemmer()

# Text preprocessing function
def preprocess_text(text):
    text = text.lower()
    doc = nlp(text)
    words = [stemmer.stem(token.text) for token in doc if token.text not in stop_words and token.is_alpha]
    return " ".join(words)

# Cosine similarity calculation
def calculate_similarity(text1, text2):
    text1 = preprocess_text(text1)
    text2 = preprocess_text(text2)
    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform([text1, text2])
    similarity = cosine_similarity(tfidf_matrix[0], tfidf_matrix[1])
    return similarity[0][0]

# Extract text from a PDF
def extract_text_from_pdf(file_path):
    try:
        reader = PdfReader(file_path)
        text = ""
        for page in reader.pages:
            text += page.extract_text()
        return text.strip()
    except Exception as e:
        return f"Error extracting text from PDF: {e}"

# Route for home page
@app.route('/')
def home():
    return render_template('index.html')

# Route for plagiarism checking
@app.route('/check', methods=['POST'])
def check_plagiarism():
    if request.method == 'POST':
        text1 = request.form.get('text1', '')
        text2 = request.form.get('text2', '')
        file1 = request.files.get('file1')
        file2 = request.files.get('file2')

        # Process text1 or uploaded file1
        if file1 and file1.filename.endswith('.pdf'):
            file1_path = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(file1.filename))
            file1.save(file1_path)
            text1 = extract_text_from_pdf(file1_path)

        # Process text2 or uploaded file2
        if file2 and file2.filename.endswith('.pdf'):
            file2_path = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(file2.filename))
            file2.save(file2_path)
            text2 = extract_text_from_pdf(file2_path)

        # Validate inputs
        if not text1 or not text2:
            result = "Error: Provide both text or PDF files to compare!"
            similarity_score = 0
        else:
            # Calculate similarity
            similarity_score = calculate_similarity(text1, text2)
            # Define plagiarism threshold
            threshold = 0.8
            if similarity_score > threshold:
                result = f"Plagiarism detected! (Similarity: {similarity_score:.2f})"
            else:
                result = f"No plagiarism detected. (Similarity: {similarity_score:.2f})"
        
        return render_template('index.html', result=result, similarity_score=similarity_score)

if __name__ == "__main__":
    app.run(debug=True)
