# Project-plagiarism

This program is a Flask web application designed to check for plagiarism between two pieces 
of text or PDFs by comparing their similarity using cosine similarity. Below is a detailed 
explanation of its key components: 
 
1. Libraries Used 
 Flask: Used to build the web application. It handles routing and form submissions. 
 spaCy: Handles natural language processing tasks such as tokenization. 
 scikit-learn: Provides tools for text vectorization (TF-IDF) and cosine similarity 
calculation. 
 NLTK: Supplies stopwords and the Porter Stemmer for preprocessing. 
 PyPDF2: Extracts text from uploaded PDF files. 
 Werkzeug: Ensures safe file uploads. 
 os: Manages file paths and directories. 
 
2. Key Functionalities 
Text Preprocessing 
 Converts text to lowercase. 
 Removes stopwords using NLTK's predefined list of English stopwords. 
 Uses spaCy for tokenization and filters out non-alphabetic tokens. 
 Applies stemming to reduce words to their root forms. 
Cosine Similarity 
 Texts are transformed into TF-IDF vectors using TfidfVectorizer. 
 Cosine similarity is calculated to compare the two TF-IDF vectors, resulting in a 
similarity score between 0 and 1. 
PDF Text Extraction 
 Extracts text from uploaded PDFs using the PdfReader from the PyPDF2 library. 
 Handles multi-page PDFs by concatenating text from all pages. 
 
3. Application Flow 
1. Home Page (/): 
o Serves an HTML template (index.html) that allows users to input two texts or 
upload two PDF files for comparison. 
2. Plagiarism Checking (/check): 
o Accepts inputs via a form (POST request): 
 Direct text inputs (text1, text2). 
 Optional PDF uploads (file1, file2). 
o Processes text or extracts text from the uploaded PDFs. 
o Preprocesses the texts and calculates their similarity. 
o Displays the result based on the similarity score: 
 A threshold of 0.8 is used to determine plagiarism. 
 
4. Plagiarism Detection Logic 
 Similarity Score Calculation: 
o If the similarity score is greater than 0.8, the text is flagged as plagiarized. 
o Otherwise, it indicates no plagiarism. 
 Both the similarity score and the result are displayed on the output page. 
 
5. Usage Example 
 Input two pieces of text or upload two PDFs. 
 Click "Check Plagiarism". 
 The application computes the similarity score and displays the result. 
 
6. Key Technical Points 
 Error Handling: 
o Ensures valid text or PDFs are provided before processing. 
o Displays an error message if inputs are incomplete. 
 File Management: 
o Uploaded PDFs are saved to a temporary folder (./uploads). 
o Uses secure_filename to prevent malicious file uploads. 
 Threshold Customization: 
o The plagiarism detection threshold can be adjusted based on the use case. 
 
The program leverages some techniques that are commonly used in machine learning (ML) 
workflows. 
 
 
ML Components in the Program 
1. TF-IDF (Term Frequency-Inverse Document Frequency): 
o This is a statistical measure used to evaluate the importance of a word in a 
document relative to a collection of documents. 
o Implemented using TfidfVectorizer from scikit-learn. 
o It converts the input text into numerical feature vectors that can be analyzed 
mathematically. 
o Relevance to ML: TF-IDF is a preprocessing step often used in natural 
language processing (NLP) tasks like classification or clustering. 
2. Cosine Similarity: 
o A mathematical measure to calculate the similarity between two vectorized 
representations (TF-IDF vectors in this case). 
o Relevance to ML: While cosine similarity itself isn't "machine learning," it is 
commonly used in recommendation systems and NLP pipelines to measure 
document similarity. 
 
